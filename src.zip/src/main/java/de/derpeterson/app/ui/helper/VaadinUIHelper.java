package de.derpeterson.app.ui.helper;

import com.vaadin.flow.component.html.Div;

public class VaadinUIHelper {

    private VaadinUIHelper() {}

    public static Div createFullHorizontalSpace() {
        Div div = new Div();
        div.setWidthFull();
        return div;
    }
}
