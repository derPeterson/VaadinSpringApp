package de.derpeterson.app.security;

import com.vaadin.flow.server.VaadinSession;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SecurityService {

    private static final String AUTH_USER_SESSION_KEY = "authenticatedUser";

    public Optional<UserDetails> getAuthenticatedUser(HttpServletRequest request) {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();
        if (authentication != null && authentication.isAuthenticated() && authentication.getPrincipal() instanceof UserDetails userDetails) {
            return Optional.of(userDetails);
        }

        UserDetails user = null;
        if (VaadinSession.getCurrent() != null) {
            user = VaadinSession.getCurrent().getAttribute(UserDetails.class);
        }

        if (user == null) {
            HttpSession httpSession = request.getSession(false);
            if (httpSession != null) {
                user = (UserDetails) httpSession.getAttribute(AUTH_USER_SESSION_KEY);
            }
        }

        if (user != null) {
            restoreSecurityContext(user);
            return Optional.of(user);
        }

        return Optional.empty();
    }

    public void storeAuthenticatedUser(HttpServletRequest request, UserDetails user) {
        if (VaadinSession.getCurrent() != null) {
            VaadinSession.getCurrent().setAttribute(UserDetails.class, user);
        }

        HttpSession httpSession = request.getSession();
        httpSession.setAttribute(AUTH_USER_SESSION_KEY, user);

        restoreSecurityContext(user);
    }

    private void restoreSecurityContext(UserDetails user) {
        Authentication auth = new UsernamePasswordAuthenticationToken(user, user.getPassword(), user.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(auth);
    }

    public void logout(HttpServletRequest request) {
        if (VaadinSession.getCurrent() != null) {
            VaadinSession.getCurrent().getSession().invalidate();
        }
        HttpSession httpSession = request.getSession(false);
        if (httpSession != null) {
            httpSession.invalidate();
        }
        SecurityContextHolder.clearContext();
    }
}
