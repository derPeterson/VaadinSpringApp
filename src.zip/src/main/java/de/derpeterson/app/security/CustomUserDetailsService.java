package de.derpeterson.app.security;

import de.derpeterson.app.model.Role;
import de.derpeterson.app.model.User;
import de.derpeterson.app.repository.UserRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    @PersistenceContext
    private EntityManager entityManager;

    private final UserRepository userRepository;

    @Override
    @Transactional(readOnly = true)
    public synchronized UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        try {
            User user = userRepository.findByEmail(email)
                    .orElseThrow(() -> new UsernameNotFoundException("User not found: " + email));

            System.out.println("🔄 Hibernate Session: " + entityManager.unwrap(Session.class).isOpen());

            // 🔄 Rollen manuell laden
            user = entityManager.find(User.class, user.getId());

            // 🔄 Rollen manuell nachladen
            Hibernate.initialize(user.getRoles());

            System.out.println("🔍 Benutzer gefunden: " + user.getEmail());
            System.out.println("🔒 Rollen aus der DB: " + user.getRoles().size());
            user.getRoles().forEach(role -> System.out.println("📋 Rolle: " + role.getName()));

            Set<GrantedAuthority> authorities = user.getRoles().stream()
                    .map(Role::getName)
                    .map(roleName -> roleName.startsWith("ROLE_") ? roleName : "ROLE_" + roleName)
                    .map(SimpleGrantedAuthority::new)
                    .collect(Collectors.toSet());

            return new org.springframework.security.core.userdetails.User(
                    user.getEmail(), user.getPassword(), user.isEnabled(), true, true, true, authorities);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }
}
